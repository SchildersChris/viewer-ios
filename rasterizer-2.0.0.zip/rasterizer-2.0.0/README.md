# Rasterizer
This repository contains a simple rasterizer with demo written in C. Additionally this repository
can be used as a Swift Package.
![Example output](output.jpg)